export default {
  debug: false, // 是否debug
  blankTitle: "New tab", // 页签默认文本
  startPage: "http://192.168.3.157:7002/auth1/login", // 开始启动页地址
  // startPage: "http://www.baidu.com", // 开始启动页地址
  disabledInput: true, // 是否禁用输入框
  hasPlusBtn: false // 是否显示添加按钮
};
