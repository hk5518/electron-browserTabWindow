// import { ipcRenderer, remote } from "electron";
import { ipcRenderer } from "electron";
window.ipcRenderer = ipcRenderer;

// ;(function(doc, win) {
//     doc.addEventListener('mouseup', function(e) {
//         let selectonText = win.getSelection();
//         if (selectonText) {
//             ipcRenderer.send("selectText");
//         }
//     }, false);

// })(document, window)
